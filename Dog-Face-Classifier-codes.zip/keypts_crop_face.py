#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr 17 12:06:31 2019

@author: jingsun
"""


import numpy as np
import torch
from scipy.misc import imsave
from skimage import io
import cv2



def get_center(keypts):
    center_point = torch.zeros(2)
    
    center_point += keypts[1]  # left eye
    center_point += keypts[0]   # right eye
    center_point += keypts[2]  # nose
    center_point /= 3

    return center_point
    
    
def write_cropped_faces(model, sample, data_list, output_size, input_prefix, output_dir):
    l = output_size
    images, _ = sample
    images = images.type(torch.FloatTensor)
    
    keypts = model(images)
    keypts = keypts.view(keypts.size()[0], 8, -1)
     
    for i, dog_file in enumerate(data_list):
        
        
        img_name = input_prefix.format(dog_file)
        img = io.imread(img_name)  
        img = cv2.resize(img, (256,256))
        
        center = get_center(keypts[i])
        left = max(int(center[0]) - output_size//2, 0)
        top = max(int(center[1]) - output_size//2, 0)
       
        cropped_img = img[top: top + l, left: left + l]
        cropped_img = np.asarray(cropped_img)
        
        crop_file = 'c_' + str(int(dog_file[:3])) + '_' + dog_file.split('/')[1]
        imsave(output_dir.format(crop_file), cropped_img)

    
