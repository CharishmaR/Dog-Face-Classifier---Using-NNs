import cv2
import matplotlib.pyplot as plt
import pandas as pd
import torch
from torchvision import transforms
import torch.nn as nn
import torch.optim as optim
import torchvision.models as models

from keypts_extract_data import *
from keypts_image_processing import *
from keypts_modeling import *
from keypts_crop_face import *


CROPPED_TRAIN_DIR = 'cropped_images/train'
CROPPED_TEST_DIR = 'cropped_images/test'

train_dataset = CroppedDogDataset(root_dir='cropped_images/train', transform=cropped_ToTensor())
test_dataset = CroppedDogDataset(root_dir='cropped_images/test', transform=cropped_ToTensor())



#img, l = train_dataset[666]
#plt.imshow(img.transpose(0,2).transpose(0,1))
#print(l)

#
#cnn_model = models.alexnet(pretrained = True) # no pretraining
#cnn_model.classifier = nn.Linear(9216, 133) # replace classification layer.
#cnn_model.eval()

cnn_model = SimpleCNN()
n_epochs = 10
loss_fn = nn.CrossEntropyLoss()
learningRate = 1e-3
optimizer = optim.SGD(cnn_model.parameters(), lr = learningRate, momentum = 0.9)

train_breed_model(n_epochs, cnn_model, loss_fn, optimizer, train_dataset, test_dataset)





