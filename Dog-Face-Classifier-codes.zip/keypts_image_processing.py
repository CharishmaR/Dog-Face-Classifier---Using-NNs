# CS6501 - final project
# Dog-Face-Classifier
# keypts_image_processing.py
# 4/12/19


import cv2
import numpy as np
import pandas as pd
from skimage import io
import torch
import os
from torch.utils.data import Dataset


class FacialKeypointsDataset(Dataset):
    """Face Landmarks dataset."""

    def __init__(self, csv_file, root_dir, transform=None):
        self.key_pts_frame = pd.read_csv(csv_file)
        self.root_dir = root_dir
        self.transform = transform

    def __len__(self):
        return len(self.key_pts_frame)

    def __getitem__(self, idx):
        image_name = os.path.join(self.root_dir,
                                  self.key_pts_frame.iloc[idx, 0])
        
        image = io.imread(image_name)
        key_pts = self.key_pts_frame.iloc[idx, 1:].as_matrix()
        key_pts = key_pts.astype('float').reshape(-1, 2)
        sample = [image, key_pts]

        if self.transform:
            sample = self.transform(sample)
        return sample
    
    
class CroppedDogDataset(Dataset):

    def __init__(self, root_dir, transform=None):
        self.root_dir = root_dir
        self.cropped_images = os.listdir(root_dir)
        self.transform = transform

    def __len__(self):
        return len(self.cropped_images)

    def __getitem__(self, idx):
        image_name = os.path.join(self.root_dir, self.cropped_images[idx])
        image = io.imread(image_name)
       
        
        label = int(self.cropped_images[idx].split('_')[1])-1
        #sample = {'image': image, 'label': label}
        sample = [image, label]
        
        if self.transform:
            sample = self.transform(sample)
                
        return sample
    


class Normalize(object):
    """Convert a color image to grayscale and normalize the color range to [0,1]."""        

    def __call__(self, sample):
        image, key_pts = sample
        
        # convert image to grayscale
        image = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        image = image/255.0

        return [image, key_pts]
    


class Rescale(object):
    """Rescale the image in a sample to a given size.

    Args:
        output_size (tuple or int): Desired output size. If tuple, output is
            matched to output_size. If int, smaller of image edges is matched
            to output_size keeping aspect ratio the same.
    """

    def __init__(self, output_size):
        assert isinstance(output_size, (int, tuple))
        self.output_size = output_size

    def __call__(self, sample):
        image, key_pts = sample

        h, w = image.shape[:2]
        img = cv2.resize(image, (self.output_size, self.output_size))
        
        # scale the pts, too
        key_pts = key_pts * [self.output_size/w, self.output_size/h]

        return [img, key_pts]



class CropFace(object):
    """Crop randomly the image in a sample.

    Args:
        output_size (tuple or int): Desired output size. If int, square crop
            is made.
    """

    def __init__(self, output_size):
        assert isinstance(output_size, (int, tuple))
        if isinstance(output_size, int):
            self.output_size = (output_size, output_size)
        else:
            assert len(output_size) == 2
            self.output_size = output_size

    def __call__(self, sample):
        image, key_pts = sample

        h, w = image.shape[:2]
        new_h, new_w = self.output_size
        
        dog_top = min([i[1] for i in key_pts])-5
        dog_left = min([i[0] for i in key_pts])-5
        
        top = np.random.randint(0, min(0, dog_top))
        left = np.random.randint(0, min(0, dog_left))

        image = image[top: top + new_h,
                      left: left + new_w]

        key_pts = key_pts - [left, top]

        return [image, key_pts]
    
    
    
class RandomCrop(object):
    def __init__(self, output_size):
        assert isinstance(output_size, (int, tuple))
        if isinstance(output_size, int):
            self.output_size = (output_size, output_size)
        else:
            assert len(output_size) == 2
            self.output_size = output_size

    def __call__(self, sample):
        image, key_pts = sample['image'], sample['keypoints']

        h, w = image.shape[:2]
        new_h, new_w = self.output_size
        
        top = np.random.randint(0, h - new_h)
        left = np.random.randint(0, w - new_w)
        
        image = image[top: top + new_h,
                      left: left + new_w]

        key_pts = key_pts - [left, top]

        return {'image': image, 'keypoints': key_pts}




class ToTensor(object):

    def __call__(self, sample):
        image, key_pts = sample
         
        # if image has no grayscale color channel, add one
        if(len(image.shape) == 2):
            # add that third color dim
            image = image.reshape(image.shape[0], image.shape[1], 1)
            
        # swap color axis because
        # numpy image: H x W x C
        # torch image: C X H X W
        image = image.transpose((2, 0, 1))
        
        return [torch.from_numpy(image),torch.from_numpy(key_pts)]
    
 
class cropped_ToTensor(object):
    
    def __call__(self, sample):
        image, label = sample
         
        # if image has no grayscale color channel, add one
        if(len(image.shape) == 2):
            image = image.reshape(image.shape[0], image.shape[1], 1)
            
        # swap color axis because
        # numpy image: H x W x C
        # torch image: C X H X W
        image = image.transpose((2, 0, 1))/255.0
        
        return [torch.from_numpy(image),label]