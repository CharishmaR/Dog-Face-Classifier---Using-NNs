import cv2
import matplotlib.pyplot as plt
import pandas as pd
import torch
from torchvision import transforms
import torch.nn as nn
import torch.optim as optim

from sklearn.model_selection import train_test_split

from keypts_extract_data import *
from keypts_image_processing import *
from keypts_modeling import *
from keypts_crop_face import *


# removed 074.Giant_schnauzer/Giant_schnauzer_05108 from training
# removed 098.Leonberger/Leonberger_06571 from training
# removed 103.Mastiff/Mastiff_06832 from test
train_list = get_training_list()
test_list = get_testing_list()

train = get_data(train_list)
test = get_data(test_list)

cols = ['img_name','f1_x','f1_y','f2_x','f2_y','f3_x','f3_y','f4_x','f4_y',
        'f5_x','f5_y','f6_x','f6_y','f7_x','f7_y','f8_x','f8_y']            
train = pd.DataFrame(train, columns = cols)
test = pd.DataFrame(test, columns = cols)
dev, val = train_test_split(train, test_size = 0.2)
print(train.shape, test.shape, dev.shape, val.shape)
# (4774, 17) (3574, 17) (3819, 17) (955, 17)

train.to_csv('train.csv', index=False)
test.to_csv('test.csv', index=False)
dev.to_csv('dev.csv', index=False)
val.to_csv('val.csv', index=False)      

#count = 0
#for dog_file in train_list:
#    image = cv2.imread(IMAGE_PREFIX.format(dog_file))
#    if (image.shape[0] < 224) or (image.shape[1] < 224):
#        count += 1
#        print(image.shape, dog_file)
#print(count)

           
train_dataset = FacialKeypointsDataset(csv_file='train.csv',
                                       root_dir='CU_Dogs/dogImages/',
                                       transform=transforms.Compose([
                                               Rescale(256),
                                               Normalize(),
                                               ToTensor()
                                               ]))

dev_dataset = FacialKeypointsDataset(csv_file='dev.csv',
                                     root_dir='CU_Dogs/dogImages/',
                                     transform=transforms.Compose([
                                               Rescale(256),
                                               Normalize(),
                                               ToTensor()
                                               ]))
            
val_dataset = FacialKeypointsDataset(csv_file='val.csv',
                                     root_dir='CU_Dogs/dogImages/',
                                     transform=transforms.Compose([
                                               Rescale(256),
                                               Normalize(),
                                               ToTensor()
                                               ]))
            
test_dataset = FacialKeypointsDataset(csv_file='test.csv',
                                      root_dir='CU_Dogs/dogImages/',
                                      transform=transforms.Compose([
                                               Rescale(256),
                                               Normalize(),
                                               ToTensor()
                                               ]))

# checking for bad images
#for i in range(4699, 4774):
#    sample = train_dataset[i]
#    image, keypts = sample
#    print(i, image.size(), keypts.size())
    
## plotting images
img, l = train_dataset[666]
plt.imshow(img.transpose(0,2)[:,:,0].transpose(0,1), cmap='gray')
plt.scatter(l[:,0], l[:,1], s=20, marker='.', c='m')

    
  
## dataloaders
batch_size = 64
train_loader = torch.utils.data.DataLoader(dataset = train_dataset,
                                           batch_size = batch_size,
                                           shuffle = True,
                                           num_workers = 0)

test_loader = torch.utils.data.DataLoader(dataset = test_dataset,
                                          batch_size = batch_size,
                                          shuffle = True,
                                          num_workers = 0)

dev_loader = torch.utils.data.DataLoader(dataset = dev_dataset,
                                           batch_size = batch_size,
                                           shuffle = True,
                                           num_workers = 0)

val_loader = torch.utils.data.DataLoader(dataset = val_dataset,
                                          batch_size = batch_size,
                                          shuffle = True,
                                          num_workers = 0)



n_epochs = 3
model = keypts_CNN()
loss_fn = nn.MSELoss()
learning_rate = 1e-2
optimizer = optim.Adam(params = model.parameters(), lr = learning_rate)

## train model
train_keypts_model(n_epochs, model, loss_fn, optimizer, train_loader, val_loader)




## visualize model outputs
test_images, test_outputs, gt_pts = net_sample_output(model, test_loader)
print(test_images.data.size())
print(test_outputs.data.size())
print(gt_pts.size())
visualize_output(test_images, test_outputs, 5, gt_pts)





#### write cropped faces
batch_size = 20
train_loader = torch.utils.data.DataLoader(dataset = train_dataset,
                                           batch_size = batch_size,
                                           shuffle = False,
                                           num_workers = 0)

test_loader = torch.utils.data.DataLoader(dataset = test_dataset,
                                          batch_size = batch_size,
                                          shuffle = False,
                                          num_workers = 0)


### c_6_American_eskimo_dog_0046711
IMAGE_PREFIX = 'CU_Dogs/dogImages/{}.jpg'
TRAIN_DIR = 'cropped_images/train/{}.png'
for i, sample in enumerate(train_loader):
    start = i * batch_size
    end = (i+1) * batch_size
    if end > len(train_list):
        end = len(train_list)
    write_cropped_faces(model, sample, train_list[start:end], 224, IMAGE_PREFIX, TRAIN_DIR)
    

TEST_DIR = 'cropped_images/test/{}.png'
for i, sample in enumerate(test_loader):
    start = i * batch_size
    end = (i+1) * batch_size
    if end > len(test_list):
        end = len(test_list)
    write_cropped_faces(model, sample, test_list[start:end], 224, IMAGE_PREFIX, TEST_DIR)



    


