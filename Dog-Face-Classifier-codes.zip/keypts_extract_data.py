# CS6501 - final project
# Dog-Face-Classifier
# keypts_extract_data.py
# 4/12/19



IMAGE_PREFIX = 'CU_Dogs/dogImages/{}.jpg'
POINT_PREFIX = 'CU_Dogs/dogParts/{}.txt'



def get_training_list():
    train_images = []
    with open('CU_Dogs/training.txt', 'r') as in_file:
        for line in in_file.readlines():
            train_images.append(line.strip().replace('.jpg', ''))
    return train_images




def get_testing_list():
    test_images = []

    with open('CU_Dogs/testing.txt', 'r') as in_file:
        for line in in_file.readlines():
            test_images.append(line.strip().replace('.jpg', ''))
    return test_images




def get_data(data_list):
    data = []
    for dog_file in data_list:
        row = []
        row.append(dog_file + '.jpg')
        with open(POINT_PREFIX.format(dog_file),'r') as parts:
            for line in parts.readlines():
                x,y = line.split()
                row.append(int(x));row.append(int(y))
        data.append(row)
    return data


    

