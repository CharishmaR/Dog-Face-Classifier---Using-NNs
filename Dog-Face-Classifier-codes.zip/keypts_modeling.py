# CS6501 - final project
# Dog-Face-Classifier
# keypts_modeling.py
# 4/12/19


import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
import numpy as np

class keypts_CNN(nn.Module):

    def __init__(self):
        super(keypts_CNN, self).__init__()
        
        self.conv1 = nn.Conv2d(1, 32, 5)
        self.pool1 = nn.MaxPool2d(2, 2)
        
        self.conv2 = nn.Conv2d(32, 64, 3)
        self.pool2 = nn.MaxPool2d(2, 2)
        
        self.conv3 = nn.Conv2d(64, 128, 3)
        self.pool3 = nn.MaxPool2d(2, 2)
        
        self.conv4 = nn.Conv2d(128, 256, 3)
        self.pool4 = nn.MaxPool2d(2, 2)
        
        self.fc1 = nn.Linear(14*14*256 , 1024)
        self.fc2 = nn.Linear(1024,16)
        
        self.drop1 = nn.Dropout(p = 0.1)
        self.drop2 = nn.Dropout(p = 0.2)
        self.drop3 = nn.Dropout(p = 0.2)
        self.drop4 = nn.Dropout(p = 0.2)
        self.drop5 = nn.Dropout(p = 0.6)

    def forward(self, x):
        x = self.drop1(self.pool1(F.relu(self.conv1(x))))
        x = self.drop2(self.pool2(F.relu(self.conv2(x))))
        x = self.drop3(self.pool3(F.relu(self.conv3(x))))
        x = self.drop4(self.pool4(F.relu(self.conv4(x))))
        x = x.view(x.size(0), -1)
        x = self.drop5(F.relu(self.fc1(x)))
        x = self.fc2(x)
        
        return x


class keypts_FFNN(nn.Module):

    def __init__(self):
        super(keypts_FFNN, self).__init__()
        
        self.fc1 = nn.Linear(1*256*256 , 10000)
#         self.fc2 = nn.Linear(1024,1024)
        self.fc2 = nn.Linear(10000,2000)
        self.fc3 = nn.Linear(2000, 500)
        self.fc4 = nn.Linear(500, 100)
        self.fc5 = nn.Linear(100, 16)
        
        self.drop1 = nn.Dropout(p = 0.1)
        self.drop2 = nn.Dropout(p = 0.2)
        self.drop3 = nn.Dropout(p = 0.2)
        self.drop4 = nn.Dropout(p = 0.2)
        #self.drop5 = nn.Dropout(p = 0.6)

        
    def forward(self, x):
        x = x.view(x.size(0), -1)
        x = self.drop1(F.relu(self.fc1(x)))
        x = self.drop2(F.relu(self.fc2(x)))
        x = self.drop3(F.relu(self.fc3(x)))
        x = self.drop4(F.relu(self.fc4(x)))
        #x = self.drop5(F.relu(self.fc5(x)))
        x = self.fc5(x)
        
        return x
    
    
    

class SimpleCNN(torch.nn.Module):
        
    def __init__(self):
        super(SimpleCNN, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=11, stride=4, padding=2), #224-11-4/4+1 = 53
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2), 
            
            nn.Conv2d(64, 192, kernel_size=5, padding=2),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
            
            nn.Conv2d(192, 384, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            
            nn.Conv2d(384, 256, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2) 
        )
                   
        self.classifier = nn.Sequential(
            nn.Dropout(),
            nn.Linear(256*6*6, 1000),
            nn.ReLU(inplace = True),
            nn.Dropout(),
            nn.Linear(1000, 500),
            nn.ReLU(inplace = True),
            nn.Linear(500, 133)
        )
        
    def forward(self, x):
        x = self.features(x)    
        x = x.view(x.size(0), 256*6*6)
        x = self.classifier(x)
        return(x)
        




def train_keypts_model(n_epochs, model, loss_fn, optimizer, train_loader, val_loader):
    train_losses = []; val_losses = [] 
    
    for epoch in range(n_epochs): 
        
        cum_loss = 0.0
        model.train()        
        for (i, (images, keypts)) in enumerate(train_loader):
         
            images = images.type(torch.FloatTensor)
            keypts = keypts.type(torch.FloatTensor)
            keypts = keypts.view(keypts.size(0), -1)
        
            scores = model(images)
            loss = loss_fn(scores, keypts)
            cum_loss += loss.item()
            
            optimizer.zero_grad()            
            loss.backward()
            optimizer.step()

            if (i + 1) % 10 == 0:
                print('Train-epoch %d. Iteration %05d, Avg-Loss: %.4f' % 
                     (epoch, i + 1, cum_loss / (i + 1)))
                
        train_losses.append(cum_loss / (i + 1))
         
        cum_loss = 0.0
        model.eval()       
        for (i, (images, keypts)) in enumerate(val_loader):
            images = images.type(torch.FloatTensor)
            keypts = keypts.type(torch.FloatTensor)
            keypts = keypts.view(keypts.size(0), -1)            
            
            scores = model(images)
            cum_loss += loss_fn(scores, keypts).item()
    
        val_losses.append(cum_loss / (i + 1))        
        print('Validation-epoch %d. Avg-Loss: %.4f' % 
             (epoch, cum_loss / (i + 1)))
            
    print('Finished Training')





def train_breed_model(n_epochs, model, loss_fn, optimizer, train_dataset, test_dataset):  
    batch_size = 20
    train_loader = torch.utils.data.DataLoader(dataset = train_dataset,
                                               batch_size = batch_size,
                                               shuffle = True,
                                               num_workers = 0)

    test_loader = torch.utils.data.DataLoader(dataset = test_dataset,
                                              batch_size = batch_size,
                                              shuffle = False,
                                              num_workers = 0)

    train_accuracies = []; val_accuracies = []
    train_accuraciesk = []; val_accuraciesk = []
    train_losses = []; val_losses = []
    
    for epoch in range(n_epochs):
        correct = 0.0
        correctk = 0.0
        cum_loss = 0.0
    
        model.train()
        for (i, (inputs, labels)) in enumerate(train_loader):
            inputs = inputs.type(torch.FloatTensor)
            scores = model(inputs)
            loss = loss_fn(scores, labels)
    
            max_scores, max_labels = scores.max(1)
            maxk_scores, maxk_labels = scores.topk(5, 1, True, True)
              
            correct += (max_labels == labels).sum().item()
            correctk += maxk_labels.eq(labels.view(-1, 1).expand_as(maxk_labels)).sum().item()
            cum_loss += loss.item()
              
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
    
            if (i + 1) % 100 == 0:
                print('Train-epoch %d. Iteration %05d, Avg-Loss: %.4f, Accuracy: %.4f, Accuracy-5: %.4f' % 
                        (epoch, i + 1, cum_loss / (i + 1), correct / ((i + 1) * batch_size), 
                                                           correctk / ((i + 1) * batch_size)))
    
        train_accuracies.append(correct / len(train_dataset))
        train_accuraciesk.append(correctk / len(train_dataset))
        train_losses.append(cum_loss / (i + 1))   
    
          # Make a pass over the validation data.
        correct = 0.0
        correctk = 0.0
        cum_loss = 0.0
        model.eval()
        for (i, (inputs, labels)) in enumerate(test_loader):
            inputs = inputs.type(torch.FloatTensor)
            scores = model(inputs)
            cum_loss += loss_fn(scores, labels).item()
    
            max_scores, max_labels = scores.max(1)
            maxk_scores, maxk_labels = scores.topk(5, 1, True, True)
            correct += (max_labels == labels).sum().item()
            correctk += maxk_labels.eq(labels.view(-1, 1).expand_as(maxk_labels)).sum().item()
    
        val_accuracies.append(correct / len(test_dataset))
        val_accuraciesk.append(correctk / len(test_dataset))
        val_losses.append(cum_loss / (i + 1))
    
          # Logging the current results on validation.
        print('Validation-epoch %d. Avg-Loss: %.4f, Accuracy: %.4f, Accuracy-5: %.4f' % 
                (epoch, cum_loss / (i + 1), correct / len(test_dataset),
                                            correctk / len(test_dataset)))


  



def net_sample_output(model, test_loader):
    
    # iterate through the test dataset
    for i, sample in enumerate(test_loader):
        
        # get sample data: images and ground truth keypoints
        images, keypts = sample
        images = images.type(torch.FloatTensor)
        
        # forward pass to get net output
        output_pts = model(images)
        output_pts = output_pts.view(output_pts.size()[0], 8, -1)
        
        # break after ith batch images are tested
        if i == 1:
            return images, output_pts, keypts
        
        

def show_all_keypoints(image, predicted_keypts, gt_pts=None):

    plt.imshow(image, cmap='gray')
    plt.scatter(predicted_keypts[:,0], predicted_keypts[:,1], s=20, marker='.', c='m')
    # plot ground truth points as green pts
    if gt_pts is not None:
        plt.scatter(gt_pts[:, 0], gt_pts[:,1], s=50, marker='.', c='g') 
        
        
        
def visualize_output(test_images, test_outputs, batch_size, gt_pts=None):

    for i in range(batch_size):
        plt.figure(figsize=(20,10))
        plt.subplot(1, batch_size, i+1)

        # un-transform the image data
        image = test_images[i].data   # get the image from it's Variable wrapper
        image = image.numpy()   # convert to numpy array from a Tensor
        image = np.transpose(image, (1, 2, 0))   # transpose to go from torch to numpy image

        # un-transform the predicted keypts data
        predicted_keypts = test_outputs[i].data
        predicted_keypts = predicted_keypts.numpy()
        # undo normalization of keypoints  
        #predicted_keypts = predicted_keypts*50.0+100
        
        # plot ground truth points for comparison, if they exist
        ground_truth_pts = None
        if gt_pts is not None:
            ground_truth_pts = gt_pts[i]         
            #ground_truth_pts = ground_truth_pts*50.0+100
        
        show_all_keypoints(np.squeeze(image), predicted_keypts, ground_truth_pts)
            
        plt.axis('off')

    plt.show()